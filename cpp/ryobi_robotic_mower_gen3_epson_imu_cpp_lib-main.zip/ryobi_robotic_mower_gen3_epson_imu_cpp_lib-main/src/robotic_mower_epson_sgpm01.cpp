#include "robotic_mower_epson_sgpm01.h"

#define imu_msg_header_frame 0x8001
#define imu_msg_end_frame    0x0D0A

static char command_cal_gro_zero[] = {0xFF, 0x1C, 0x00, 0x00, 0x00, 0x00, 0xC5, 0xD6};
static char command_clear_yaw[]    = {0xFF, 0X1E, 0x00, 0x00, 0x00, 0x00, 0xBC, 0x16};


/**
 * @brief Constructor for the robotic_mower_epson_sgpm01 class.
 *
 * @param port_name The name of the serial port to open.
 */
robotic_mower_epson_sgpm01::robotic_mower_epson_sgpm01()
{
}

robotic_mower_epson_sgpm01::~robotic_mower_epson_sgpm01()
{
    close(fd);
}

/**
 * @brief Initializes the IMU by opening the serial port and starting the receive thread.
 *
 * @param port_name The name of the serial port to open.
 */

int robotic_mower_epson_sgpm01::imu_init(const char *port_name)
{
    if (serial_open(&fd, port_name, false) < 0)
    {
        close(fd);
        return -1;
    }

    // start the rx thread of the imu
    imu_rx_thread = std::thread(&robotic_mower_epson_sgpm01::imu_rx_thread_update, this);
    imu_rx_thread.detach();

    reset_state = 0;
    comm_status = false;
    return 0;
}

/**
 * @brief Updates the IMU receive thread.
 *
 * This function continuously reads data from the serial port and processes it to update the IMU data buffer.
 * It checks for the header and end frame in the received data, verifies the checksum, and copies the data to the temporary
 * buffer. The data is then parsed and stored in the IMUDATABUF structure.
 *
 * @note This function runs in an infinite loop until the program is terminated.
 */
void robotic_mower_epson_sgpm01::imu_rx_thread_update()
{
    int  ret      = -1;
    int  rx_size  = 76;
    auto start_ts =  std::chrono::system_clock::now();

    while (1)
    {
        if (reset_state >= 0)
        {
            reset_state -= 10;
            comm_status = false;
        }
        else
        {
            ret = serial_read(&fd, imu_rx_buff, rx_size);
            if (ret >= 0)
            {
                // get ths header index from imu_rx_buff
                uint8_t temp_msg_frame[38] = {0};

                for (int i = 0; i < ret; i++)
                {
                    // check the header
                    if (imu_rx_buff[i] == ((imu_msg_header_frame >> 8) & 0xFF)
                        && imu_rx_buff[i + 1] == (imu_msg_header_frame & 0xFF)
                        && imu_rx_buff[i + 36] == ((imu_msg_end_frame >> 8) & 0xFF)
                        && imu_rx_buff[i + 37] == (imu_msg_end_frame & 0xFF))
                    {
                        if (!msg_checksum(&imu_rx_buff[i]))
                        {
                            break;
                        }
                        else
                        {
                            start_ts    =  std::chrono::system_clock::now();
                            // copy the imu_rx_buff to temp buffer
                            memcpy(temp_msg_frame, &imu_rx_buff[i], (size_t)38);

                            // // print the temp_msg_frame
                            // printf("temp_msg_frame: ");
                            // for (int i = 0; i < 38; i++)
                            // {
                            //     printf("%02X ", temp_msg_frame[i]);
                            // }
                            // printf("\n");

                            // parse the data
                            IMUDATABUF.header = (uint16_t)(temp_msg_frame[0] << 8) | temp_msg_frame[1];

                            IMUDATABUF.GX          = (int16_t)(temp_msg_frame[7] << 8) | temp_msg_frame[6];
                            IMUDATABUF.GY          = (int16_t)(temp_msg_frame[9] << 8) | temp_msg_frame[8];
                            IMUDATABUF.GZ          = (int16_t)(temp_msg_frame[11] << 8) | temp_msg_frame[10];
                            IMUDATABUF.AX          = (int16_t)(temp_msg_frame[13] << 8) | temp_msg_frame[12];
                            IMUDATABUF.AY          = (int16_t)(temp_msg_frame[15] << 8) | temp_msg_frame[14];
                            IMUDATABUF.AZ          = (int16_t)(temp_msg_frame[17] << 8) | temp_msg_frame[16];
                            IMUDATABUF.pitch       = (int16_t)(temp_msg_frame[19] << 8) | temp_msg_frame[18];
                            IMUDATABUF.roll        = (int16_t)(temp_msg_frame[21] << 8) | temp_msg_frame[20];
                            IMUDATABUF.yaw         = (int16_t)(temp_msg_frame[23] << 8) | temp_msg_frame[22];
                            IMUDATABUF.MX          = (int16_t)(temp_msg_frame[25] << 8) | temp_msg_frame[24];
                            IMUDATABUF.MY          = (int16_t)(temp_msg_frame[27] << 8) | temp_msg_frame[26];
                            IMUDATABUF.MZ          = (int16_t)(temp_msg_frame[29] << 8) | temp_msg_frame[28];
                            IMUDATABUF.Aziumth     = (int16_t)(temp_msg_frame[31] << 8) | temp_msg_frame[30];
                            IMUDATABUF.temperature = (int16_t)(temp_msg_frame[33] << 8) | temp_msg_frame[32];

                            IMUDATABUF.checksum = (uint16_t)(temp_msg_frame[35] << 8) | temp_msg_frame[34];
                            IMUDATABUF.end      = (uint16_t)(temp_msg_frame[36] << 8) | temp_msg_frame[37];
                        }
                        break;
                    }
                }
            }

            // msg timeout
            if (std::chrono::system_clock::now() - start_ts >=  std::chrono::milliseconds(1000))
            {
                comm_status = false;
            }
            else {
                comm_status = true;
            }
            
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
}

bool robotic_mower_epson_sgpm01::get_comm_status(){
    return comm_status;
}

int robotic_mower_epson_sgpm01::cal_gro_zero()
{
    if (serial_write(&fd, command_cal_gro_zero, sizeof(command_cal_gro_zero)) < 0)
    {
        return -1;
    }
    else
    {
        // wait 8 sec for calibration
        reset_state = 8000;
        return 0;
    }
}

int robotic_mower_epson_sgpm01::reset_yaw()
{
    if (serial_write(&fd, command_clear_yaw, sizeof(command_clear_yaw)) < 0)
    {
        return -1;
    }
    else
    {
        reset_state = 1000;
        return 0;
    }
}

float robotic_mower_epson_sgpm01::get_gx()
{
    return (float)IMUDATABUF.GX / 64.0f;
}

float robotic_mower_epson_sgpm01::get_gy()
{
    return (float)IMUDATABUF.GY / 64.0f;
}

float robotic_mower_epson_sgpm01::get_gz()
{
    return (float)IMUDATABUF.GZ / 64.0f;
}

float robotic_mower_epson_sgpm01::get_ax()
{
    return (float)IMUDATABUF.AX / 1.0f;
}

float robotic_mower_epson_sgpm01::get_ay()
{
    return (float)IMUDATABUF.AY / 1.0f;
}

float robotic_mower_epson_sgpm01::get_az()
{
    return (float)IMUDATABUF.AZ / 1.0f;
}

float robotic_mower_epson_sgpm01::get_pitch()
{
    return (float)IMUDATABUF.pitch / 100.0f;
}

float robotic_mower_epson_sgpm01::get_roll()
{
    return (float)IMUDATABUF.roll / 100.0f;
}

float robotic_mower_epson_sgpm01::get_yaw()
{
    return (float)IMUDATABUF.yaw / 100.0f;
}

float robotic_mower_epson_sgpm01::get_mx()
{
    return (float)IMUDATABUF.MX / 100.0f;
}

float robotic_mower_epson_sgpm01::get_my()
{
    return (float)IMUDATABUF.MY / 100.0f;
}

float robotic_mower_epson_sgpm01::get_mz()
{
    return (float)IMUDATABUF.MZ / 100.0f;
}

float robotic_mower_epson_sgpm01::get_azimuth()
{
    return (float)IMUDATABUF.Aziumth / 100.0f;
}

/**
 * @brief Get the temperature from the IMU data buffer.
 *
 * @return The temperature in degrees Celsius.
 */
float robotic_mower_epson_sgpm01::get_temperature()
{
    return (float)IMUDATABUF.temperature / 100.0f;
}

int robotic_mower_epson_sgpm01::get_status()
{
    return (int)IMUDATABUF.status;
}

/**
 * Opens a serial device and configures its settings.
 *
 * @param fd A pointer to an integer that will hold the file descriptor of the opened device.
 * @param dev The path to the serial device.
 * @param rts_485 A boolean indicating whether to configure the device for RS485 mode.
 * @return 0 if the device is successfully opened and configured, -1 otherwise.
 */
int robotic_mower_epson_sgpm01::serial_open(int *fd, const char *dev, bool rts_485)
{
    struct termios opt;

    /* open serial device */
    if ((*fd = open(dev, O_RDWR)) < 0)
    {
        perror("open()");
        return -1;
    }

    /* define termois */
    if (tcgetattr(*fd, &opt) < 0)
    {
        perror("tcgetattr()");
        return -1;
    }

    /* Configuration of 485 mode */
    if (rts_485)
    {
        struct serial_rs485 rs485_conf;
        rs485_conf.flags |= SER_RS485_ENABLED;
        rs485_conf.flags &= ~SER_RS485_RTS_ON_SEND;
        rs485_conf.flags |= SER_RS485_RTS_AFTER_SEND;
        rs485_conf.flags |= SER_RS485_RX_DURING_TX;
        if (ioctl(*fd, TIOCSRS485, &rs485_conf) < 0)
        {
            perror("rs485_conf");
            return -1;
        }
    }

    opt.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    opt.c_oflag &= ~OPOST;

    // custom
    // opt.c_cflag |= (CLOCAL|CREAD);

    /* Character length, make sure to screen out this bit before setting the data bit */
    opt.c_cflag &= ~CSIZE;

    /* No hardware flow control */
    opt.c_cflag &= ~CRTSCTS;

    /* 8-bit data length */
    opt.c_cflag |= CS8;

    /* 1-bit stop bit */
    opt.c_cflag &= ~CSTOPB;

    /* No parity bit */
    opt.c_iflag |= IGNPAR;

    /* Disable Input Parity Checking */
    opt.c_iflag &= ~INPCK;

    /* Disable software flow control */
    opt.c_iflag &= ~(IXON | IXOFF | IXANY);

    opt.c_iflag &= ~(IGNPAR | ICRNL);

    /* output raw data */
    opt.c_oflag &= ~OPOST;

    /* Output mode */
    opt.c_oflag = 0;

    /* No active terminal mode */
    opt.c_lflag = 0;

    opt.c_cc[VMIN] = 13;
    opt.c_cc[VTIME] = 10;

    /* Input baud rate */
    if (cfsetispeed(&opt, B115200) < 0)
        return -1;

    /* Output baud rate */
    if (cfsetospeed(&opt, B115200) < 0)
        return -1;

    /* Overflow data can be received, but not read */
    if (tcflush(*fd, TCIFLUSH) < 0)
        return -1;

    if (tcsetattr(*fd, TCSANOW, &opt) < 0)
        return -1;

    tcflush(*fd, TCIFLUSH);

    return 0;
}

int robotic_mower_epson_sgpm01::serial_write(int *fd, char *data, size_t size)
{
    int ret = write(*fd, data, size);
    if (ret < 0)
    {
        perror("write");
        tcflush(*fd, TCOFLUSH);
    }
    return ret;
}

int robotic_mower_epson_sgpm01::serial_read(int *fd, char *data, size_t size)
{
    int num_bytes = read(*fd, data, size);
    if (num_bytes < 0)
    {
        printf("Error reading: %s", strerror(errno));
        return 1;
    }
    else
    {
        return num_bytes;
    }
}

bool robotic_mower_epson_sgpm01::msg_checksum(char *data)
{
    uint16_t checksum = 0;
    for (int i = 2; i <= 33; i++)
    {
        checksum += (uint8_t)data[i];
    }
    if (checksum == (uint16_t)(data[35] << 8 | data[34]))
    {
        return true;
    }
    else
    {
        return false;
    }
}


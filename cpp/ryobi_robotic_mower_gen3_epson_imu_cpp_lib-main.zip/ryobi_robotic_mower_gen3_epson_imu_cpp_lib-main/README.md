# Robotic Mower Epson SGPM01 C++ Library

This is a C++ library for controlling the Epson SGPM01 IMU (Inertial Measurement Unit) in a robotic mower.

## Installation

To use this library, follow these steps:

1. Clone the repository: `git clone https://github.com/your-username/robotic_mower_epson_sgpm01_cpp_lib.git`
2. go to the project diretory `cd robotic_mower_epson_sgpm01_cpp_lib`
2. make a build directory `mkdir build`
2. Build the library: `cmake ../ && make`
3. Install the library: `sudo make install`

## Usage

To use the library in your own project, include the header file `epson_sgpm01.h` and link against the library `libepson_sgpm01.so`.

Here's an example test application `epson_sgpm01_test.cpp` that displays the basic information of the IMU:

Example output:
```bash
IMU Data:
status: 0
gx: 0.00 deg/s
gy: 0.00 deg/s
gz: 0.00 deg/s
ax: 829.00 mg
ay: 93.00 mg
az: 575.00 mg
pitch: 5.27 deg
roll: -55.39 deg
yaw: -43.60 deg
mx: -28.41 uT
my: -9.73 uT
mz: -101.60 uT
azimuth: 105.90 deg
temperature: 23.31 C

```



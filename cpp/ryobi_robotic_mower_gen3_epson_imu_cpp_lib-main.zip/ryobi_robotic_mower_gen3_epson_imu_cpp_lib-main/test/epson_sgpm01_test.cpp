#include "robotic_mower_epson_sgpm01.h"
#include <chrono>
#include <thread>

/**
 * @brief This is a simple example to show how to use the robotic_mower_epson_sgpm01 class.
 * example output
 *   IMU Data:
     status: 0
     gx: 0.00 deg/s
     gy: 0.00 deg/s
     gz: 0.00 deg/s
     ax: 0.00 mg
     ay: 0.00 mg
     az: 0.00 mg
     pitch: 0.00 deg
     roll: 0.00 deg
     yaw: 0.00 deg
     mx: 0.00 uT
     my: 0.00 uT
     mz: 0.00 uT
     azimuth: 0.00 deg
     temperature: 0.00 C
*/
const char port_name[] = "/dev/ttyS7";

robotic_mower_epson_sgpm01 epson_imu;

/**
 * @brief The main function of the program.
 *
 * This function initializes the IMU, prints the IMU data in a loop, and sleeps for 100 milliseconds between each iteration.
 *
 * @return int Returns 0 upon successful execution.
 */
int main()
{
    if (epson_imu.imu_init(port_name) != 0)
    {
        printf("IMU init failed!\r\n");
        return -1;
    }
    else
    {
        epson_imu.cal_gro_zero();
        epson_imu.reset_yaw();
        while (1)
        {
            if (epson_imu.get_comm_status())
            {
                // print all the imu data
                printf("IMU Data:\r\n");
                printf("status: %d\r\n", epson_imu.get_status());
                printf("gx: %.2f deg/s\r\n", epson_imu.get_gx());
                printf("gy: %.2f deg/s\r\n", epson_imu.get_gy());
                printf("gz: %.2f deg/s\r\n", epson_imu.get_gz());
                printf("ax: %.2f mg\r\n", epson_imu.get_ax());
                printf("ay: %.2f mg\r\n", epson_imu.get_ay());
                printf("az: %.2f mg\r\n", epson_imu.get_az());
                printf("pitch: %.2f deg\r\n", epson_imu.get_pitch());
                printf("roll: %.2f deg\r\n", epson_imu.get_roll());
                printf("yaw: %.2f deg\r\n", epson_imu.get_yaw());
                printf("mx: %.2f uT\r\n", epson_imu.get_mx());
                printf("my: %.2f uT\r\n", epson_imu.get_my());
                printf("mz: %.2f uT\r\n", epson_imu.get_mz());
                printf("azimuth: %.2f deg\r\n", epson_imu.get_azimuth());
                printf("temperature: %.2f C\r\n", epson_imu.get_temperature());
                printf("\r\n\r\n");
                std::this_thread::sleep_for(std::chrono::milliseconds(50));
            }
            else{
                printf("communication failed\r\n");
                std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            }
            
        }
    }
    return 0;
}

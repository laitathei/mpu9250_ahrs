#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <termios.h>
#include <string.h>
#include <errno.h>
#include <stdbool.h>
#include <libgen.h>
#include <signal.h>
#include <getopt.h>
#include <linux/serial.h>
#include <iostream>
#include <cstring>
#include <unistd.h>
#include <thread>
#include <sys/types.h>
#include <chrono>

struct _IMU_
{
    uint16_t header;
    uint16_t counter;
    uint16_t status;
    int16_t  GX;
    int16_t  GY;
    int16_t  GZ;
    int16_t  AX;
    int16_t  AY;
    int16_t  AZ;
    int16_t  pitch;
    int16_t  roll;
    int16_t  yaw;
    int16_t  MX;
    int16_t  MY;
    int16_t  MZ;
    int16_t  Aziumth;
    int16_t  temperature;
    int16_t  checksum;
    uint16_t end;
} IMUDATABUF;

class robotic_mower_epson_sgpm01
{
public:
    robotic_mower_epson_sgpm01();
    ~robotic_mower_epson_sgpm01();

    int imu_init(const char *port_name);
    int cal_gro_zero();
    int reset_yaw();

    bool get_comm_status();
    float get_gx();
    float get_gy();
    float get_gz();
    float get_ax();
    float get_ay();
    float get_az();
    float get_pitch();
    float get_roll();
    float get_yaw();
    float get_mx();
    float get_my();
    float get_mz();
    float get_azimuth();
    float get_temperature();
    int   get_status();

    int16_t reset_state;
private:

    bool comm_status; 
    int serial_write(int *fd, char *data, size_t size);
    int serial_read(int *fd, char *data, size_t size);
    int serial_close(int *fd);
    int serial_open(int *fd, const char *dev, bool rts_485);

    int  fd;
    char imu_tx_buff[38] = {0};
    char imu_rx_buff[50] = {0};

    bool msg_checksum(char *data);
    std::thread imu_rx_thread;
    void imu_rx_thread_update();
};